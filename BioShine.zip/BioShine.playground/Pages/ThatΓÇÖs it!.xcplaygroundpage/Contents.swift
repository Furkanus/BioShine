
/*:
 
 # That's it!
 
 ### You've finished this playground 🥳, you learned lot's of things.If you are interest in bioluminescence you can not stop and continue the researching 🧐.
 ### I hope I could add something to you take care of yourself.
 
 ###  Good Bye 👋
 
 */

import SwiftUI
import PlaygroundSupport

struct ThatsItView : View {
    @State private var visible : Bool = false
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            ZStack {
                VStack(spacing : 20) {
                    Text("That's it 🥳")
                        .font(.system(size: 50))
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .animation(.linear(duration: 2.5))
                        .opacity(visible ? 1 : 0)
                        .animation(.easeIn(duration: 3.0))
                    
                    Text("You are finished this playground, see you in the Dub Dub 🤘")
                        .font(.system(size: 25))
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .animation(.linear(duration: 3.5))
                        .opacity(visible ? 1 : 0)
                        .animation(.easeIn(duration: 3.0))
                        .lineSpacing(5.0)
                    
                    Text("Thank you so much for trying this playground 😍")
                        .font(.system(size: 20))
                        .fontWeight(.regular)
                        .foregroundColor(.white)
                        .animation(.linear(duration: 3.5))
                        .opacity(visible ? 1 : 0)
                        .animation(.easeIn(duration: 3.0))
                        .lineSpacing(5.0)
                    
                }.frame(width: 300, height: 300) 
                .padding(.bottom , 100)
                
                Image(uiImage:  #imageLiteral(resourceName: "me.PNG"))
                    .resizable()
                    .scaledToFit()
                    .clipShape(RoundedRectangle(cornerRadius: 25))
                    .animation(.linear(duration: 3.5))
                    .opacity(visible ? 1 : 0)
                    .animation(.easeIn(duration: 3.0))
                    .frame(width: 200, height: 150)
                    .shadow(color: .white, radius: 20)
                    .position(x: 500, y: 600)
                
            }.onAppear {
                self.visible = true
            }
        }.preferredColorScheme(.dark)
    }
}

var view = UIHostingController(rootView: ThatsItView())
view.preferredContentSize = CGSize(width: 800, height: 600)
PlaygroundPage.current.liveView = view
PlaygroundPage.current.needsIndefiniteExecution = true
