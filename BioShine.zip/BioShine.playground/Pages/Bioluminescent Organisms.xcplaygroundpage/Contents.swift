
/*:
 ## Pretty good, now we will learn __some bioluminescent organisms__
 
 1. Jellyfish
 2. Anglerfish
 3. Mushrooms🍄
 4. Firefly🪳
 5. Planktons
 6. Cookiecutter Shark🦈
 */
import SwiftUI
import PlaygroundSupport

struct OrganismView : View {
    @State private var imgHeight : CGFloat = 150
    @State private var imgWidth : CGFloat = 150
    private let images  = ["anglerFish" , "babyShark" , "bioFlower" , "jellyFish"  , "firefly" , "mushroom"]
    private let names = ["Anglerfish" , "CookieCutter Shark" , "Flower ", "Jellyfish" , "Firefly" , "Mushroom"]
    var body : some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            ZStack {
                ScrollView(.horizontal , showsIndicators: false) {
                    
                    HStack(spacing: 50) {
                        ForEach(0..<6) { item in
                            VStack {
                                Image(uiImage: UIImage(named: images[item % images.count])!)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: imgWidth, height: imgHeight)
                                    .clipShape(Circle())
                                
                                Text(names[item % names.count])
                                    .font(.system(size: 30))
                                    .font(.system(.callout))
                                
                            }
                            
                        }
                        
                    }.padding(.top , 30)
                    Spacer()
                }
                
                HStack {
                    Text("Scroll")
                        .font(.system(size: 30))
                        .foregroundColor(.white)
                        .fontWeight(.bold)
                    
                    Image(systemName: "arrow.right")
                        .foregroundColor(.white)
                        .font(.system(size: 60))
                }.padding(.bottom , 170)
                
                VStack() {
                    Spacer()
                    HStack {
                        Text("Do you know?:")
                            .font(.system(size: 30))
                            .foregroundColor(.white)
                        Spacer()
                    }.padding(.leading , 15)
                    
                        
                    Spacer().frame( height: 20)
                    
                    Text("Anglerfish hunt by waving objects in front of its mouth that its prey is attracted to. The glowing lure of the deep sea anglerfish draws in prey with its attractive light, bringing them towards its impressive jaws. The darkness of the deep sea makes it difficult to locate much of anything, and the glowing fishing lure of the deep sea anglerfish is perfect for drawing in prey and potential mates alike.I think this is so effective hunting type 😃.")
                        .font(.system(size: 20))
                        .fontWeight(.light)
                        .foregroundColor(.white)
                        .lineSpacing(7)
                        .padding(.horizontal , 12)
                    
                    Spacer().frame( height: UIScreen.main.bounds.size.height * 0.14)
                }
            }
        }.preferredColorScheme(.dark)
    }
}

var success = NSLocalizedString("Bioluminescent organism's too much in the world this is certain types 🤩 \n\n[**Next Page**](@next)", comment:"Success message")
PlaygroundPage.current.assessmentStatus = .pass(message: success)

var view = UIHostingController(rootView: OrganismView())
view.preferredContentSize = CGSize(width: 800, height: 600)
PlaygroundPage.current.liveView = view
PlaygroundPage.current.needsIndefiniteExecution = true
