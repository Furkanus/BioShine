
/*:
 ## Alright, let's take the firefly 🪳
 
 ### Luciferin pigment (possessed by the firefly) is react with oxygen 💨
 ### Luciferace enzyme (possessed by the firefly) is speed up the reaction 🧪
 
 */

/*:
 ## OK, but why does firefly need light? 💡
 
 ### Male fireflies also light up to signal their desire for mates, and willing females attract the males with flashes of their own and communicate with other firefly's.
 
 ℹ️ [Why does the Firefly need to make light?](https://www.scientificamerican.com/article/how-and-why-do-fireflies/).
 
 */


import PlaygroundSupport
import SwiftUI

struct Firefly : View {
    private let fireSecond : Double = 5.0
    private let flySecond : Double = 3.5
    private let second : Double = 1.0
    private let secondd : Double = 2.0
    @State private var cases : Int = 0
    @State private var all : Bool = false
    @State private var fireVisible : Bool = false
    @State private var flyVisible : Bool = false
    @State private var imgHeight : CGFloat = 300
    @State private var imgWidth : CGFloat = 300
    @State private var visible : Bool = false
    @State private var visiblee : Bool = false
    @State private var visibilityy : Bool = true
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            ZStack {
                VStack { 
                    HStack(spacing: 10) {
                        // Luciferase
                        Image(uiImage:  #imageLiteral(resourceName: "luciferaseFormula.png"))
                            .resizable()
                            .scaledToFit()
                            .opacity(visible ? 1 : 0)
                            .animation(.easeInOut(duration: 1.5))
                            .frame(width: imgWidth, height: imgHeight)
                        
                        //Luciferin
                        Image(uiImage:  #imageLiteral(resourceName: "luciferinFormula.png"))
                            .resizable()
                            .scaledToFit()
                            .opacity(visible ? 1 : 0)
                            .animation(.easeInOut(duration: 1.5))
                            .frame(width: imgWidth, height: imgHeight)
                        
                    }.padding(.trailing , 30)
                    
                    
                }
                
                VStack(spacing : -60) {
                    Spacer()
                    Image(uiImage: #imageLiteral(resourceName: "fireflyNolight.png"))
                        .resizable()
                        .scaledToFit()
                        .clipShape(Circle())
                        .opacity(flyVisible ? 1 : 0)
                        .animation(.easeIn(duration: 1.5))
                        .frame(width: imgWidth, height: imgHeight)
                    
                    
                    RoundedRectangle(cornerRadius: 20)
                        .foregroundColor(.yellow)
                        .frame(width: 20, height: 45)
                        .rotationEffect(Angle(degrees: 50))
                        .padding(.trailing , 45)
                        .opacity(fireVisible ? 1 : 0)
                        .offset(y: -100)
                    
                }
                
            }
            
            
            Image(systemName: "plus")
                .font(.system(size: 33))
                .opacity(visiblee ? 1 : 0)
                .foregroundColor(.white)
                .animation(.easeInOut(duration: 1.5))
                .padding(.trailing , 80)
            
            
            HStack {  
                Text("Luciferase")
                    .font(.system(size: 25))
                    .foregroundColor(.yellow)
                    .opacity(visible ? 1 : 0)
                    .foregroundColor(.white)
                    .animation(.easeInOut(duration: 1.5))
                    .position(x: UIScreen.main.bounds.width * 0.1, y: UIScreen.main.bounds.size.height * 0.51)
                
                Text("Luciferin")
                    .font(.system(size: 25))
                    .foregroundColor(.yellow)
                    .opacity(visible ? 1 : 0)
                    .animation(.easeInOut(duration: 1.5))
                    .position(x: UIScreen.main.bounds.width * 0.07, y: UIScreen.main.bounds.size.height * 0.51)
                
                
            }
            
            Text("That's all 🥳")
                .font(.system(size: 50))
                .fontWeight(.bold)
                .opacity(all ? 1 : 0)
                .foregroundColor(.white)
                .animation(.easeOut(duration: 2.0))
                .padding(.bottom , 500)
            
        }.preferredColorScheme(.dark)
        .onAppear {
            
            DispatchQueue.main.asyncAfter(deadline: .now() + second) {
                self.visible = true
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + secondd) {
                self.visiblee = true
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + flySecond) {
            self.flyVisible = true
                
            }
            
            
            
            DispatchQueue.main.asyncAfter(deadline: .now() + fireSecond) {
                
                var timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { tim in
                    
                    self.fireVisible.toggle()
                    self.cases += 1
                    if cases == 5 {
                        tim.invalidate()
                        self.all = true
                        var success = NSLocalizedString("That's all.Now, you know 'How Firefly create own light with Bioluminescence' 🤩 \n\n[**Next Page**](@next)", comment:"Success message")
                        PlaygroundPage.current.assessmentStatus = .pass(message: success)
                        
                        
                    }
                }
            }
        }
    }
    
}

var view = UIHostingController(rootView: Firefly())
view.preferredContentSize = CGSize(width: 800, height: 600)
PlaygroundPage.current.liveView = view
PlaygroundPage.current.needsIndefiniteExecution = true
