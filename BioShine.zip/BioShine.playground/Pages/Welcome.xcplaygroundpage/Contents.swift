
/*:
 # __BioShine__ ✨
 
 Preliminary information:
 
 The uses of bioluminescence by animals include counter-illumination camouflage, mimicry of other animals, for example to lure prey, and signalling to other individuals of the same species, such as to attract mates. 🤩
 
 This is only one of information about Bioluminescence
 */

/*:
 
 if you want more about Bioluminescence click this wikipedia link [Wikipedia](https://en.wikipedia.org/wiki/Bioluminescence)
 */



import SwiftUI
import PlaygroundSupport

struct MainView : View  {
    @State private var imgHeight : CGFloat = 200
    @State private var imgWidth : CGFloat = 200
    @State private var animStart : Bool = false
    @State private var animEnd : Bool = false
    private let endAnimDuration : Double = 7.0
    private let startAnimDuration : Double = 11.0
    
    
    var body: some View {
        ZStack {
            ZStack {
                Color.black.edgesIgnoringSafeArea(.all)
                Text("Hello , My name is Furkan.I'm so excited for this year WWDC ,this playground you will learn about 'Bioluminescence'🥳.I hope you enjoy it 😍.")
                    .fontWeight(.bold)
                    .font(.largeTitle)
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .lineSpacing(10)
                    .padding()
                .rotation3DEffect(.degrees(animEnd ? 0 : 60) , axis: (x: 0 , y : 0.5 , z: 0))
                //.rotation3DEffect(.degrees(animEnd ? 0 : 60) , axis: (x: 5, y: 0, z: 0))
                    .shadow(color: .white, radius: 30, x: 15, y: 15)
                    .frame(width: 400, height: animStart ? 750 : 0)
                    .animation(Animation.linear(duration: animEnd ? endAnimDuration : startAnimDuration))
                
                HStack {
                    Image(uiImage: #imageLiteral(resourceName: "helloSticker.png"))
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 20)
                        .frame(width: imgWidth, height: imgHeight)
                        .position(x: 150, y: UIScreen.main.bounds.size.height * 0.7)
                    
                }
                
                HStack {
                    Image(uiImage:  #imageLiteral(resourceName: "wwdcSticker.png"))
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 20)
                        .frame(width: imgWidth, height: imgHeight)
                        .position(x: 150, y: 100)
                    Spacer()
                    
                    Image(uiImage:  #imageLiteral(resourceName: "me1.PNG"))
                        .resizable()
                        .scaledToFit()
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .shadow(color: .white, radius: 20)
                        .frame(width: 150, height: 150)
                        .position(x: 220, y: 100)
                    
                }
            }.onAppear {
                self.animStart.toggle()
                self.animEnd.toggle()
            }
        }.preferredColorScheme(.dark)
    }
}



var success = NSLocalizedString("Let's go to the next page \n\n[**Next Page**](@next)", comment:"Success message")
PlaygroundPage.current.assessmentStatus = .pass(message: success)

var view = UIHostingController(rootView: MainView())
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = view
