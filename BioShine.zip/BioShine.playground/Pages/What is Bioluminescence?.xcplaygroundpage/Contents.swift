
/*:
 ## So, What is the Bioluminescence?
 
 ### Bioluminescence is the production and emission of light by a living organism. It is a form of chemiluminescence.
 ℹ️ Source [Wikipedia](https://en.wikipedia.org/wiki/Bioluminescence)
 
 ## Also;
 
 ### Bioluminescent creatures supply luciferin (pigment) and luciferase (enzyme)🧪 chemicals. Luciferin, one of these chemicals, reacts with oxygen and the light-producing luciferase also accelerates this reaction. This reaction can take place both inside and outside the cell.
 
 ℹ️ Source [EvrimAgaci](https://evrimagaci.org/biyoluminesans-isik-sacan-hayvanlar-bunu-nasil-yapiyorlar-1204).
 
 */

/*:
 ## Alright, but why do these creatures need bioluminescence?
 ### Bioluminescence functions:
 
 - Camouflage
 - Defense
 - Attracting prey
 - Visualization of Prey
 - Attracting mates
 - Warning
 - Communication
 */

import SwiftUI
import PlaygroundSupport

struct BioView : View {
    @State private var visible : Bool = false
    private var gridItemLayout = [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())]
    private let images  = ["anglerFish" , "babyShark" , "bioFlower" , "jellyFish" , "organism" , "sea" , "firefly" , "strangeFish" , "mushroom"]
    private let second : Double = 3.5
    private let succses : Double = 9.0
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            ZStack {
                ScrollView(.vertical) {
                    LazyVGrid(columns: gridItemLayout , spacing : 50) {
                        ForEach((1...9), id: \.self) { img in
                            
                            Image(uiImage: UIImage(named: images[img % images.count])!)
                                .resizable()
                                .scaledToFit()
                                .opacity(visible ? 1 : 0)
                                .animation(.easeIn(duration: Double(img)))
                                .clipShape(Circle())
                        }
                    }
                    Anim()
                }
                
            }.onAppear {
                
                DispatchQueue.main.asyncAfter(deadline: .now() + second) {
                    
                    self.visible = true
                    
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + succses) {
                    var success = NSLocalizedString("Bioluminescence is so cool right?😍 It makes a very nice picture that these organisms do this 🤩 \n\n[**Next Page**](@next)", comment:"Success message")
                    PlaygroundPage.current.assessmentStatus = .pass(message: success)
                }
            }
        }.preferredColorScheme(.dark)
    }
}

struct Anim : View {
    @State private var visible : Bool = false
    private let second : Double = 2.0
    var body: some View {
        ZStack {
            Text("This is bioluminescence examples 😍")
                .font(.system(size: 30))
                .fontWeight(.ultraLight)
                .foregroundColor(.white)
                .opacity(visible ? 1 : 0)
                .animation(.easeInOut(duration: 1.5))
            
        }.preferredColorScheme(.dark)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + second) {
                self.visible = true
                
            }
        }
    }
}



var view = UIHostingController(rootView: BioView())
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = view
